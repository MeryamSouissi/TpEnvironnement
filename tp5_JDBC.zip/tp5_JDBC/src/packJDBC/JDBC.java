package packJDBC;

public class JDBC {

	   public static void main(String[] args) {
	        Impl bookDao = new Impl();
	        Book book = new Book();
	        book.setBook_id(1);
	        book.setTitle("Java");
	        book.setAuthor("James Gosling");
	        book.setPrice(1000);
	        bookDao.bookAdd(book);
	        bookDao.bookDisplay();
	        book.setTitle("Java Programming");
	        book.setAuthor("James Gosling");
	        book.setPrice(1500);
	        bookDao.bookUpdate(book);
	        bookDao.bookDisplay();
	        bookDao.bookDelete(1);
	        bookDao.bookDisplay();
	    }
	}