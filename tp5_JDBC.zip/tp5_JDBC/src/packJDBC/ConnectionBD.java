package packJDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionBD {
	private Connection con;
	public Connection getConn() {
	    try {
			  Class.forName("com.mysql.cj.jdbc.Driver");
			  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/biblio", "MyUser", "1234");
		} catch (SQLException | ClassNotFoundException e) {
			e.getStackTrace();
		}
	    return con;
	}
}

