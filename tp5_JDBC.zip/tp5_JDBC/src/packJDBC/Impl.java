package packJDBC;

import java.sql.ResultSet;
import java.sql.SQLException;


public class Impl {
	public ConnectionBD con = new ConnectionBD();

	public void bookAdd(Book book) {
	    	try {
	    		String sql = "INSERT INTO book (book_id, title, author, price) VALUES ('"+book.getBook_id() +"', '"+book.getTitle() +"','"+ book.getAuthor()+"','"+ book.getPrice()+"')";
	    		con.getConn().createStatement().executeUpdate(sql);
	    		}catch(SQLException e){
			  System.out.println(e.getMessage());
		}
	}
	public void bookUpdate(Book book) {
	    try {
	        String sql = "UPDATE book SET title = '"+book.getTitle()+"', author = '"+book.getAuthor()+"', price = '"+book.getPrice()+"' WHERE book_id = '"+book.getBook_id()+"'";
	        con.getConn().createStatement().executeUpdate(sql);
	        }catch(SQLException e){
	          System.out.println(e.getMessage());
	    }
	}

	public void bookDelete(int bookId) {
	    try {
	        String sql = "DELETE FROM book WHERE book_id = '"+bookId+"'";
	        con.getConn().createStatement().executeUpdate(sql);
	        }catch(SQLException e){
	          System.out.println(e.getMessage());
	}
	}
	public void bookDisplay() {
		try {
	        String sql = "SELECT * FROM book";
	        ResultSet rs = con.getConn().createStatement().executeQuery(sql);
			while(rs.next()) {
			    System.out.println("Book ID: "+rs.getLong(1));
			    System.out.println("Title: "+rs.getString(2));
			    System.out.println("Author: "+rs.getString(3));
			    System.out.println("Price: "+rs.getFloat(4));
			}
	        }catch(SQLException e){
	          System.out.println(e.getMessage());
	    }
	}

	public Book bookFind(String kw){        
		Book book = new Book();
		try {
	        
	        String query = "SELECT * FROM book WHERE title LIKE '%"+kw+"%' OR author LIKE '%"+kw+"%'";

	        ResultSet rs;
			rs = con.getConn().createStatement().executeQuery(query);
			while (rs.next()) {
			    book.setBook_id(rs.getInt(1));
			    book.setTitle(rs.getString(2));             
			    book.setAuthor(rs.getString(3));
			    book.setPrice(rs.getFloat(4));
			}
	    } catch (SQLException e) {
	        System.out.println(e.getMessage());
	    }
		return book;
	}  
	
}