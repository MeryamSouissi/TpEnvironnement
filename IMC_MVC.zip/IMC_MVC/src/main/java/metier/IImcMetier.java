package metier;
public interface IImcMetier{
	public double calculerImc(int poids, double taille);
}