package packDAO;

import java.sql.ResultSet;
import java.sql.SQLException;

public class BookDaoImpl {
	public ConnectionFactory con = new ConnectionFactory();

public void addBook(BookBean book) {
    	try {
    		String sql = "INSERT INTO tp5 (book_id, title, author, price) VALUES ('"+book.getBook_id() +"', '"+book.getTitle() +"','"+ book.getAuthor()+"','"+ book.getPrice()+"')";
    		try {
				con.getConn().createStatement().executeUpdate(sql);
			} catch (ClassNotFoundException e) {
				  System.out.println(e.getMessage());
			}
    		}catch(SQLException e){
		  System.out.println(e.getMessage());
	}
}
public void updateBook(BookBean book) {
    try {
        String sql = "UPDATE tp5 SET title = '"+book.getTitle()+"', author = '"+book.getAuthor()+"', price = '"+book.getPrice()+"' WHERE book_id = '"+book.getBook_id()+"'";
        try {
            con.getConn().createStatement().executeUpdate(sql);
        } catch (ClassNotFoundException e) {
              System.out.println(e.getMessage());
        }
        }catch(SQLException e){
          System.out.println(e.getMessage());
    }
}

public void deleteBook(int bookId) {
    try {
        String sql = "DELETE FROM tp5 WHERE book_id = '"+bookId+"'";
        try {
            con.getConn().createStatement().executeUpdate(sql);
        } catch (ClassNotFoundException e) {
              System.out.println(e.getMessage());
        }
        }catch(SQLException e){
          System.out.println(e.getMessage());
}
}
public void displayAll() {
	try {
        String sql = "SELECT * FROM tp5";
        try {
            ResultSet rs = con.getConn().createStatement().executeQuery(sql);
            while(rs.next()) {
                System.out.println("Book ID: "+rs.getLong(1));
                System.out.println("Title: "+rs.getString(2));
                System.out.println("Author: "+rs.getString(3));
                System.out.println("Price: "+rs.getFloat(4));
            }
        } catch (ClassNotFoundException e) {
              System.out.println(e.getMessage());
        }
        }catch(SQLException e){
          System.out.println(e.getMessage());
    }
}

public BookBean findBook(String kw){        
	BookBean book = new BookBean();
	try {
        
        String query = "SELECT * FROM tp5 WHERE title LIKE '%"+kw+"%' OR author LIKE '%"+kw+"%'";

        ResultSet rs;
		try {
			rs = con.getConn().createStatement().executeQuery(query);
			while (rs.next()) {
	            book.setBook_id(rs.getLong(1));
	            book.setTitle(rs.getString(2));             
	            book.setAuthor(rs.getString(3));
	            book.setPrice(rs.getFloat(4));
	        }

		} catch (ClassNotFoundException e) {
	        System.out.println(e.getMessage());
		}
    } catch (SQLException e) {
        System.out.println(e.getMessage());
    }
	return book;
}  
}