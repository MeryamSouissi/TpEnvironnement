package packDAO;

public class Main {
    public static void main(String[] args) {
        BookDaoImpl bookDao = new BookDaoImpl();
        BookBean book = new BookBean();
        book.setBook_id(1);
        book.setTitle("Mathematics");
        book.setAuthor("Meryam Souissi");
        book.setPrice(1000);
        bookDao.addBook(book);
        bookDao.displayAll();
        book.setTitle("Architecture");
        book.setAuthor("Souissi Meryam");
        book.setPrice(1500);
        bookDao.updateBook(book);
        bookDao.displayAll();
        bookDao.deleteBook(1);
        bookDao.displayAll();
    }
}