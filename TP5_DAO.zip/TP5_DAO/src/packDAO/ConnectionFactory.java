package packDAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
		private Connection conn;

		public Connection getConn() throws ClassNotFoundException, SQLException {
			  Class.forName("com.mysql.cj.jdbc.Driver");
		        conn = DriverManager.getConnection("jdbc:mysql://localhost/dao","root","");
			return conn;
		}
}