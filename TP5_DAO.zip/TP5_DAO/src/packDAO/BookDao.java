package packDAO;

public interface BookDao {
	public void addBook(BookBean book);	
	public void updateBook(BookBean book);
	public void deleteBook(Long book_id);
	public void displayAll();
}
