package mod;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import form.beans.NoteForm;
import mod.sco.Scolarite;

public class ControleurServlet extends HttpServlet{
	@Override
	public void doPost(
    		HttpServletRequest request,
    		HttpServletResponse response)
    		throws ServletException, IOException {
    		Scolarite sco=new Scolarite();
    		NoteForm nf=new NoteForm();

    		nf.setNum_Ins(request.getParameter("num_Ins"));
			try {

				nf.setLesNotes(sco.getNotes(nf.getNum_Ins()));

			} catch (ClassNotFoundException e) {
				System.out.print(e.getMessage());
			}
			HttpSession session=request.getSession();
			session.setAttribute("nf",nf);
		    response.sendRedirect("Notes.jsp");

			}
	
	
	
}
