package mod.sco;

import java.util.Vector;

class TestMetier{
	public static void main(String args[]) throws ClassNotFoundException {
		Scolarite s = new Scolarite();
		
		Vector<notes> ListeNote = s.getNotes("12");
		
		for(int i=0; i<ListeNote.size() ;i++) {
			System.out.print(ListeNote.get(i).getMatiere()+" "+ListeNote.get(i).getNote()+" ");
		}
	}
}