package mod.sco;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class Scolarite {
	public DataBaseConn conn = new DataBaseConn();

    public Vector<notes> getNotes(String num_Ins) throws ClassNotFoundException {
        Vector<notes> notesEtudiant = new Vector<>();

        try {
            String query = "SELECT * FROM notes WHERE num_Ins = '" + num_Ins + "'";
            ResultSet rs = conn.getConn().createStatement().executeQuery(query);

            while (rs.next()) {
                
                
                notes n = new notes();
                n.setMatiere(rs.getString("matiere"));
                n.setId_note(rs.getInt("Id_note"));
                n.setNote(rs.getFloat("note"));
                
                notesEtudiant.add(n);
            }
        } catch (SQLException e1) {
            System.out.println(e1.getMessage());
        }

        return notesEtudiant;
    }
}
