package mod.sco;
public class notes{
	public int id_note;
	public String num_ins;
	public String matiere;
	public float note;
	public int getId_note() {
		return id_note;
	}
	public void setId_note(int id_note) {
		this.id_note = id_note;
	}
	public String getNum_ins() {
		return num_ins;
	}
	public void setNum_ins(String num_ins) {
		this.num_ins = num_ins;
	}
	public String getMatiere() {
		return matiere;
	}
	public void setMatiere(String matiere) {
		this.matiere = matiere;
	}
	public float getNote() {
		return note;
	}
	public void setNote(float note) {
		this.note = note;
	}
}