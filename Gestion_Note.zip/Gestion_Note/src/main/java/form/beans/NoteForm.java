package form.beans;
import java.util.Vector;
import mod.sco.notes;

public class NoteForm{
	public String num_Ins;
	public Vector <notes> lesNotes = new Vector<>();
	public Vector<notes> getLesNotes() {
		return lesNotes;
	}
	public void setLesNotes(Vector<notes> lesNotes) {
		this.lesNotes = lesNotes;
	}
	public String getNum_Ins() {
		return num_Ins;
	}
	public void setNum_Ins(String num_Ins) {
		this.num_Ins = num_Ins;
	}


}